import sys
import numpy as np

if sys.argv.__len__() > 1:
    input = sys.argv[1]
else:
    input = "input.txt"
print(f"Reading from: {input}")
fin = open(input, "r")  # Input file provided by the platform
fout = open("output.txt", "w")  # Output file to submit

#
# FACCIO SCHIFO IN OPERAZIONI CON NUMPY/VETTORI :(
#

# do some kind of search from top and bottom
def count_intervals_min_max(N, arr):
    M = np.zeros((N, N), dtype=int)
    arr = np.array(arr)
    sort_a = np.argsort(arr)
    indexes = np.arange(N, dtype=int)
    for n, i, min_val in zip(indexes, sort_a, arr[sort_a]):
        for j, max_val in zip(sort_a[:n:-1], arr[sort_a[:n:-1]]):
            # if M[i, j] == 0:  # indexes that are not already checked
                mid_val = max_val**2 / min_val
                if mid_val % 1 == 0:
                    for k in indexes[arr == mid_val]:
                        if len({i, j, k}) == 3:
                            mn = min(i, j, k)
                            mx = max(i, j, k)
                            M[0 : mn, mx:] = 1
                mid_val = np.sqrt(max_val / min_val)
                if mid_val % 1 == 0:
                    for k in indexes[arr == mid_val]:
                        if len({i, j, k}) == 3:
                            mn = min(i, j, k)
                            mx = max(i, j, k)
                            M[0 : mn, mx:] = 1
    print(M)
    print(np.sum(M))
    return np.sum(M[np.unique(M)])

# look for all the possible root values
def count_intervals(N, arr):
    M = np.zeros((N, N), dtype=int)
    arr = np.array(arr)
    indexes = np.arange(N, dtype=int)
    sorted_arr = np.argsort(arr)
    for i, v1 in zip(indexes, arr):
        for j, v2 in zip(indexes[i:], arr[i:]):
            if np.sum(M[i:]) == 0: # no tuple starts from i
               for k, v3 in zip(sorted_arr[i:][np.sqrt(v1 * v2) == arr[i:]],
                                arr[i:][np.sqrt(v1 * v2) == arr[i:]],
                                ):




T = int(fin.readline().strip())

for _ in range(T):
    N = int(fin.readline().strip())
    a = list(map(int, fin.readline().strip().split()))
    ret = count_intervals(N, a)
    fout.write(f"{ret}\n")
    break
